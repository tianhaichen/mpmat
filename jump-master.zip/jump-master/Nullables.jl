module Nullables

include("nullable.jl")

export Nullable, NullException, isnull, unsafe_get

end # module
