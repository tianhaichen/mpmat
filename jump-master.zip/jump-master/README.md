# jump
Material Point Method in Julia

This tutorial MPM code is for the theory of the MPM described in my book 
'The Material Point Method: Theory, Implementations and Applications (Scientific Computation) 1st ed. 2023 Edition'
written with Alban de Vaucorbeil and Stephane Bordas.

Link to the book: https://link.springer.com/book/10.1007/978-3-031-24070-6
